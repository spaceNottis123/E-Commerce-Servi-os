package com.oppervision.pagamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServicoDePagamentosApplicationTests {

	@Test
	void contextLoads() {
	}

}
