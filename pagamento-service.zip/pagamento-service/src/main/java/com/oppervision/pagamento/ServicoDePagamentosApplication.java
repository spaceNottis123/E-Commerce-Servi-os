package com.oppervision.pagamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicoDePagamentosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicoDePagamentosApplication.class, args);
	}

}
