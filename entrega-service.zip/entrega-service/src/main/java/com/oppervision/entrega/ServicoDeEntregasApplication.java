package com.oppervision.entrega;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicoDeEntregasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicoDeEntregasApplication.class, args);
	}

}
